// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>
#include <stdexcept>

// Custom exception class derived from std::exception
class CustomException : public std::exception
{
    public:
    const char* what() const noexcept override
    {
        return "Custom Exception occurred.";
	}
};

bool do_even_more_custom_application_logic()
{
	throw std::runtime_error("An error occurred in Even More Custom Application Logic.");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try{
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded.";
        }
    }
    catch(const std::exception& e){
        std::cerr << "Standard exception caught: " << e.what() << std::endl;
	}

	throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    if (den == 0) {
        throw std::invalid_argument("Denominator cannot be zero.");
	}
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;
	auto result = 0.0f;

    try {
        result = divide(numerator, denominator);
    } catch (const std::invalid_argument& ia) {
        std::cerr << "Invalid argument exception caught: " << ia.what() << std::endl;
        return;
	}
     
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;

}

int main()
{
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& ce) {
		std::cerr << "Custom exception caught: " << ce.what() << std::endl;
        }
    catch (const std::exception& e) {
		std::cerr << "Standard exception caught in main: " << e.what() << std::endl;
        }
	catch (...) {
        std::cerr << "Unknown exception caught in main." << std::endl;
        }
	std::cout << "Program completed." << std::endl;
	return 0;

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu